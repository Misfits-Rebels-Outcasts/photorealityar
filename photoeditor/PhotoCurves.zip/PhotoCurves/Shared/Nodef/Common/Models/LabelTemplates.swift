//
//  Copyright © 2022 James Boo. All rights reserved.
//
/*
var scaleValues = ["Fit","Fill"]

var measurementUnits = ["Inches","Centimeters"]

var orientation = ["Portrait","Landscape"]

var propertiesHeight = 400.0
var propertiesHeightTall = 450.0




*/
var timeElapsedX = 0.0
var appType = "N" //B - B&L or N - nodef
