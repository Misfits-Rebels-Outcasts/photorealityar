//
//  Copyright © 2022 James Boo. All rights reserved.
//


import Foundation

class BaseViewModel: ObservableObject {

    
}
